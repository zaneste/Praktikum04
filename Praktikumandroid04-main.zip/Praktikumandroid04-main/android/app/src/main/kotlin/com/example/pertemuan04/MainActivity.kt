package com.example.pertemuan04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
